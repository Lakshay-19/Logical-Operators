﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Logical
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
           //Declaring Variables 
            char Input = char.Parse(txtInput.Text);
        if (txtInput.Text.Length == 1) 
        {
            //If/Else statements

            if (Input <= 'Z' && Input >= 'A')
            {
                lblOutput.Text = "The letter is upper case.";
            }
            //Lower case 
            else if (Input <= 'z' && Input >= 'a')
            {
                lblOutput.Text = "The letter is lower case.";
            }

            //Digit code
            else if (Input >= '0' && Input <= '9')
            {
                lblOutput.Text = "The character is a digit";
            }

            //Symbol code

            else
            {
                lblOutput.Text = "The character is a symbol";
            }
        }

       else
       {
           lblOutput.Text = "Enter only one character!";
       }
        
       lblOutput.Visible = true;
         
       
        }
    }
}
